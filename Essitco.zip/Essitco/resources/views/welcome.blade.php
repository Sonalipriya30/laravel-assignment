<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Your CSV File</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('/style.css') }}">
</head>

<body>

    <h2>Upload Your CSV File</h2>

    <p>Click on the "Choose File" button to upload a file:</p>

    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if (Session::has('message'))
    <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif

    <form action="{{ route('store') }}" method="post" enctype="multipart/form-data">
        @csrf
        <input type="file" id="myFile" name="filename" accept=".csv">
        <button type="submit">Upload CSV</button>
    </form>

</body>

</html>