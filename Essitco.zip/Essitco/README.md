<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## 1 million CSV record upload in Laravel

Setting up Laravel for handling the upload of 1 million CSV records involves several crucial steps:

### 1. Environment Setup:
Ensure your production environment meets the following requirements:
- PHP 8.2.12
- Laravel Framework 11.2.0
Adjust `upload_max_filesize` and `post_max_size` in `php.ini` to accommodate large file uploads (e.g., `upload_max_filesize=100M`, `post_max_size=100M`).
Set up your Laravel application accordingly.

### 2. Configuration of Environment Variables:
Update the `.env` file with appropriate settings for your production environment, including database credentials and application-specific configurations (e.g., `APP_DEBUG=false`).

### 3. Application Optimization:
Optimize the application using chunk processing, and utilize `QueueCSVData` to schedule jobs for handling the upload:
- Run the command `php artisan queue:work` to enable the queue task and upload data efficiently.

### 4. Exception Handling:
Ensure that exceptions, particularly `PostTooLargeException`, are appropriately handled. Utilize try-catch blocks to handle business logic effectively.

### Additional Notes:
- Fileupload controller is used for business logic and web.php for routing.
- Make sure to thoroughly test the application's performance and reliability, especially with large-scale data uploads.
- Consider implementing additional security measures, such as input validation and authentication, to protect against potential vulnerabilities.

For detailed instructions on setting up and running the application, refer to Laravel's official documentation and relevant resources.

Feel free to contribute to this project by submitting bug reports, feature requests, or enhancements through GitHub.

Thank you for choosing Laravel for your project! Happy coding!