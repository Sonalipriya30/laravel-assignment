<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use App\Models\Employee;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Bus\Batchable;
use Illuminate\Contracts\Queue\ShouldBeUnique;


class QueueCSVData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, Batchable;

    public $header;
    public $data;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($data, $header)
    {
        $this->data = $data;
        $this->header = $header;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            //insert data as key and value--
            $emp_data = [];
            foreach ($this->data as $val) {
                $emp_data[] = [
                    'first_name' => $val[0], 
                    'last_name' => $val[1]
                ];
                
            }
          
            Employee::insert($emp_data);
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Error processing CSV data: ' . $e->getMessage());
            
            // You can also log additional information like the data being processed, etc.
            \Log::error('Data: ' . json_encode($this->data));
            
            // You can handle the error in any other way here, such as sending notifications, etc.
            
            // You may choose to re-throw the exception to let the job fail
            // throw $e;
        }
    }
}