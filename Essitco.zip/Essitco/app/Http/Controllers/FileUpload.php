<?php

namespace App\Http\Controllers;
use App\Models\Employee;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Jobs\QueueCSVData;
use Illuminate\Support\Facades\Bus;
use Session;

class FileUpload extends Controller
{    
    /**
     * index
     *
     * @return void
     */
    public function index()
    {
        // phpinfo();
        return view('welcome');
    }
    
    /**
     * upload_csv_records
     *
     * @param  mixed $request
     * @return void
     */
    public function upload_csv_records(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'filename' => 'required|mimes:csv,txt', // Validate that the uploaded file is a CSV with a maximum size of 2MB
            ]);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator);
            }

            if ($request->hasFile('filename')) {
                
                $csvFile = $request->file('filename');
                $csv = file($csvFile->getRealPath());
                $chunks = array_chunk($csv, 1000);
                // dd($chunks);
                $header = [];
                $batch = Bus::batch([])->dispatch();
                
                foreach ($chunks as $key => $chunk) {
                    $data = array_map('str_getcsv', $chunk);
                    if ($key == 0) {
                        $header = $data[0];
                        unset($data[0]);
                    }
                    // dd($data, $header);
                   
                    $batch->add(new QueueCSVData($data, $header));
                }
                Session::flash('message', "Your CSV file uploaded successfully.");
                return redirect()->back();

            } else {
                return redirect()->back()->withErrors(['filename' => 'Please upload a CSV file']);
            }
        } catch (\Exception $e) {
            Log::error('Error occurred during CSV upload: ' . $e->getMessage());
            return redirect()->back()->withErrors(['filename' => 'An error occurred during CSV upload. Please try again later.']);
        }
    }
}