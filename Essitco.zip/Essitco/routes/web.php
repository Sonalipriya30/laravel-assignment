<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FileUpload;

Route::get('/', function () {
    return view('welcome');
});
//Routes for file Upload--
Route::get('/', [FileUpload::class,'index']);
Route::post('/', [FileUpload::class,'upload_csv_records'])->name('store');

