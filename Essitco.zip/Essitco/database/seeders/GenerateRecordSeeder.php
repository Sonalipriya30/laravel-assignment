<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Employee;
use Database\Factories\EmployeeFactory;

class GenerateRecordSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         // Define the number of records you want to create
         $numberOfRecords = 100000;

         // Define the size of each chunk
         $chunkSize = 1000;
 
         // Calculate the number of chunks required
         $numberOfChunks = ceil($numberOfRecords / $chunkSize);
 
         // Using the factory to create and insert records in chunks
         for ($i = 0; $i < $numberOfChunks; $i++) {
             $chunkRecords = min($chunkSize, $numberOfRecords - $i * $chunkSize);
             Employee::factory($chunkRecords)->create();
         }
    }
}
